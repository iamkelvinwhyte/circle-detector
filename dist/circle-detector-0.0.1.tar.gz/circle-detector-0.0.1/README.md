#  Circle Detector
A tool for detecting circles in DICOM images
The requirements are:

##  Run setup

    * git clone https://github.com/iamkelvinwhyte/circle-detector.git
    * python -m venv venv
    * activate virtual environment
    * pip install -r requirements.txt
    * python main.py

##  To install the  circle-detector package
    * Navigate to dist/
    * pip install circle-detector-1.0.tar.gz
    * Run **circle-detector** command from the command line to launch the GUI

    
