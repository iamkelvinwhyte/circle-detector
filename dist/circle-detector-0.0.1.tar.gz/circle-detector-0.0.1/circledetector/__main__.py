from circledetector.uploadgui import CircleDetectorGUI

if __name__ == '__main__':
    # Instantiate CircleDetectorGUI with custom parameters
    CircleDetectorGUI()
